<?php
/*Datos de conexion a la base de datos*/
$db_host = "localhost";
$db_post = '3306';
$db_user = "homestead";
$db_pass = "secret";
$db_name = "test";

