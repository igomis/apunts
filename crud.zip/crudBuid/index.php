<?php
include("header.php");
?>
<body>
	<nav class="navbar navbar-default navbar-fixed-top">
		<?php include('nav.php');?>
	</nav>
	<div class="container">
		<div class="content">
			<h2>Llista de clients</h2>
			<hr />

			<table class="table table-striped table-hover">
				<tr>
                    <th>DNI</th>
					<th>Nom</th>
                    <th>Adreça</th>
                    <th>Telèfon</th>
                    <th>Accions</th>
				</tr>

                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>
                                <a href="edit.php?nik=" title="Editar datos" class="btn btn-primary btn-sm"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
                                <a href="index.php?aksi=delete&nik=" title="Eliminar"  class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
                            </td>
                        </tr>

			</table>
			</div>
		</div>
	</div>
    <?php include_once "footer.php" ?>
</body>
</html>
