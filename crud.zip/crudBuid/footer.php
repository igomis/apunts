<p align="center">&copy; CIPFPBatoi <?php echo date("Y");?></p>
